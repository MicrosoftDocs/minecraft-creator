{{exclusive|bedrock}}
{{TOC|right}}
{{see also|Bedrock Edition beta add-on documentation}}
This is the '''[[add-on]] documentation''' for [[Bedrock Edition 1.17.6]].
=Version: 1.17.40.6=
== Fog Definitions ==


Fogs are setup in Json files under the resource_packs, /'name of pack'/, fogs directory.</br>

=== Fog Schema ===


```</br>--------</br>{</br>    version "format_version"</br>    object "minecraft:fog_settings"</br>    {</br>        object "description"</br>        {</br>            string "identifier" // The identifier for these fog settings. The identifier must include a namespace.</br>        }</br>        object "distance" : opt // The distance fog settings for different camera locations.</br>        {</br>            object "air" : opt // The fog settings when the camera is in the air.</br>            {</br>                color "fog_color" // The color that the fog will take on.</br>                float "fog_start"<0.000000-*> // The distance from the player that the fog will begin to appear. 'fog_start' must be less than or equal to 'fog_end'.</br>                float "fog_end"<0.000000-*> // The distance from the player that the fog will become fully opaque. 'fog_end' must be greater than or equal to 'fog_start'.</br>                string "render_distance_type"<"fixed", "render"> // Determines how distance value is used. Fixed distance is measured in blocks. Dynamic distance is multiplied by the current render distance.</br>            }</br>            object "weather" : opt // The fog settings for when the camera is in the air with active weather (rain, snow, etc..).</br>            {</br>                color "fog_color" // The color that the fog will take on.</br>                float "fog_start"<0.000000-*> // The distance from the player that the fog will begin to appear. 'fog_start' must be less than or equal to 'fog_end'.</br>                float "fog_end"<0.000000-*> // The distance from the player that the fog will become fully opaque. 'fog_end' must be greater than or equal to 'fog_start'.</br>                string "render_distance_type"<"fixed", "render"> // Determines how distance value is used. Fixed distance is measured in blocks. Dynamic distance is multiplied by the current render distance.</br>            }</br>            object "water" : opt // The fog settings when the camera is in water.</br>            {</br>                color "fog_color" // The color that the fog will take on.</br>                float "fog_start"<0.000000-*> // The distance from the player that the fog will begin to appear. 'fog_start' must be less than or equal to 'fog_end'.</br>                float "fog_end"<0.000000-*> // The distance from the player that the fog will become fully opaque. 'fog_end' must be greater than or equal to 'fog_start'.</br>                string "render_distance_type"<"fixed", "render"> // Determines how distance value is used. Fixed distance is measured in blocks. Dynamic distance is multiplied by the current render distance.</br>            }</br>            object "lava" : opt // The fog settings when the camera is in lava.</br>            {</br>                color "fog_color" // The color that the fog will take on.</br>                float "fog_start"<0.000000-*> // The distance from the player that the fog will begin to appear. 'fog_start' must be less than or equal to 'fog_end'.</br>                float "fog_end"<0.000000-*> // The distance from the player that the fog will become fully opaque. 'fog_end' must be greater than or equal to 'fog_start'.</br>                string "render_distance_type"<"fixed", "render"> // Determines how distance value is used. Fixed distance is measured in blocks. Dynamic distance is multiplied by the current render distance.</br>            }</br>            object "lava_resistance" : opt // The fog settings when the camera is in lava and the player has the lava resistance effect active.</br>            {</br>                color "fog_color" // The color that the fog will take on.</br>                float "fog_start"<0.000000-*> // The distance from the player that the fog will begin to appear. 'fog_start' must be less than or equal to 'fog_end'.</br>                float "fog_end"<0.000000-*> // The distance from the player that the fog will become fully opaque. 'fog_end' must be greater than or equal to 'fog_start'.</br>                string "render_distance_type"<"fixed", "render"> // Determines how distance value is used. Fixed distance is measured in blocks. Dynamic distance is multiplied by the current render distance.</br>            }</br>            object "powder_snow" : opt // The fog settings when the camera is inside a Powder Snow block.</br>            {</br>                color "fog_color" // The color that the fog will take on.</br>                float "fog_start"<0.000000-*> // The distance from the player that the fog will begin to appear. 'fog_start' must be less than or equal to 'fog_end'.</br>                float "fog_end"<0.000000-*> // The distance from the player that the fog will become fully opaque. 'fog_end' must be greater than or equal to 'fog_start'.</br>                string "render_distance_type"<"fixed", "render"> // Determines how distance value is used. Fixed distance is measured in blocks. Dynamic distance is multiplied by the current render distance.</br>            }</br>        }</br>        object "volumetric" : opt // The volumetric fog settings.</br>        {</br>            object "density" : opt // The density settings for different camera locations.</br>            {</br>                object "air" : opt // Fog density values as light passes through air blocks.</br>                {</br>                    float "max_density"<0.000000-1.000000> // The maximum amount of opaqueness that the ground fog will take on. A value from [0.0, 1.0].</br>                    float "max_density_height"<0.000000-320.000000> : opt // The height in blocks that the ground fog will become it's maximum density.</br>                    float "zero_density_height"<0.000000-320.000000> : opt // The height in blocks that the ground fog will be completely transparent and begin to appear. This value needs to be at least 1 higher than 'max_density_height'.</br>                    bool "uniform" : opt // When set to true, the density will be uniform across all heights.</br>                }</br>                object "water" : opt // Fog density values as light passes through water blocks.</br>                {</br>                    float "max_density"<0.000000-1.000000> // The maximum amount of opaqueness that the ground fog will take on. A value from [0.0, 1.0].</br>                    float "max_density_height"<0.000000-320.000000> : opt // The height in blocks that the ground fog will become it's maximum density.</br>                    float "zero_density_height"<0.000000-320.000000> : opt // The height in blocks that the ground fog will be completely transparent and begin to appear. This value needs to be at least 1 higher than 'max_density_height'.</br>                    bool "uniform" : opt // When set to true, the density will be uniform across all heights.</br>                }</br>                object "lava" : opt // Fog density values as light passes through lava blocks.</br>                {</br>                    float "max_density"<0.000000-1.000000> // The maximum amount of opaqueness that the ground fog will take on. A value from [0.0, 1.0].</br>                    float "max_density_height"<0.000000-320.000000> : opt // The height in blocks that the ground fog will become it's maximum density.</br>                    float "zero_density_height"<0.000000-320.000000> : opt // The height in blocks that the ground fog will be completely transparent and begin to appear. This value needs to be at least 1 higher than 'max_density_height'.</br>                    bool "uniform" : opt // When set to true, the density will be uniform across all heights.</br>                }</br>                object "lava_resistance" : opt // Fog density values as light passes through lava blocks while the player has lava resistance.</br>                {</br>                    float "max_density"<0.000000-1.000000> // The maximum amount of opaqueness that the ground fog will take on. A value from [0.0, 1.0].</br>                    float "max_density_height"<0.000000-320.000000> : opt // The height in blocks that the ground fog will become it's maximum density.</br>                    float "zero_density_height"<0.000000-320.000000> : opt // The height in blocks that the ground fog will be completely transparent and begin to appear. This value needs to be at least 1 higher than 'max_density_height'.</br>                    bool "uniform" : opt // When set to true, the density will be uniform across all heights.</br>                }</br>            }</br>            object "media_coefficients" : opt // The coefficient settings for the volumetric fog in different blocks.</br>            {</br>                object "air" : opt // Fog coefficient values while light passes through air.</br>                {</br>                    color "scattering" // Proportion of light that is scattered per block.</br>                    color "absorption" // Proportion of light that is absorbed (lost) per block.</br>                }</br>                object "water" : opt // Fog coefficient values while light passes through water.</br>                {</br>                    color "scattering" // Proportion of light that is scattered per block.</br>                    color "absorption" // Proportion of light that is absorbed (lost) per block.</br>                }</br>                object "cloud" : opt // Fog coefficient values while light passes through clouds.</br>                {</br>                    color "scattering" // Proportion of light that is scattered per block.</br>                    color "absorption" // Proportion of light that is absorbed (lost) per block.</br>                }</br>            }</br>        }</br>    }</br>}</br></br>----------</br>```</br>





== Active Fog Stack ==


The active fog stack is used to determine which fog setting to use at any given time in the game. Each player has a unique fog stack.</br></br>Whenever the game needs to determine the values for the fog, it will start at the top of the fog stack and check down it until it has found a value for the current setting type. So, if a fog setting on the stack does not not have the setting it's looking for, then it will continue down the stack and check in. If it finds no such setting, it will instead use the defaults defined by the engine.</br></br>The fog stack initially is setup as follows. Starting at the bottom:</br>- Engine Default: hard code values.</br>- Data Default: The default data driven settings.</br>- Biomes: The settings defined to be on each biome.</br>- Command: The settings set on the player by server commands.</br>

=== Engine Default ===


Hard coded values in case there are no data driven values; the implicit bottom of the stack.</br>



=== Data Default ===


Defined in "biomes_client.json" under "default" if it references a fog definition via "fog_identifier".</br>



=== Biomes ===


The biome layer is an average of all the settings defined by the biomes around the player's position. The biome settings are defined in "biomes_client.json" as well for each individual biome.</br>



=== Command ===


The command layer is all the settings set by the "/fog" command and evaluated it as one stack from top to bottom. More detail in the "Fog Command" section.</br>





== Biomes ==


Fog settings can be determined for the biomes with "biomes_client.json". In each biome entry, you can have a variable called "fog_identifier" and set a name that matches the fog setting you want to use with this biome.</br></br>The "default" entry can also be set this way and will be used underneath the biomes entries in the active fog stack.So, a biome's fog setting does not completely replace the default's setting, but instead the biome is read on top of the default as described in the "Active Fog Stack" section.</br></br>The "default" biome entry has the tag "remove_all_prior_fog" that is defaulted to "false".</br>While set to false (or if the tag is not entered), missing fog definitions will be filled in by any lower resource pack that does have the definition filled.</br>When set to true, all previous fog definitions in resource packs before the current pack that enabled it will be cleared, effectively making the current resource pack the new starting point for all fogs.</br></br>In each biome (including "default") there is the tag "inherit_from_prior_fog" that is also defaulted to "false".</br>While set to false (or if the tag is not entered), the current resource pack's biome will overwrite the currently stored "fog_identifier" tag with its own.</br>When set to true, the "fog_identifier" tags from all matching biomes will be added together and create a new merged fog definition for that biome.</br>



== Fog Command ==


"/fog" can be used to manage fog settings in this layer of the active fog stack for each player.</br></br>Fog settings in this layer are ordered via the "push", "pop", "remove" modes of the "/fog" command described below.</br>Fog Settings are evaluated top-to bottom in the active fog stack which includes top-to-bottom in this layer first.</br></br>Fog settings in this layer are saved and then restored on world load per player. In this way a fog setting that is pushed before a world save, will still apply after a world load and can then be popped.</br>

=== Push ===


Pushes a new fog setting, to specified player(s), along with a user provided ID, onto the top of the Fog Command layers of the players' active fog stacks.</br>



=== Pop ===


Removes the top-most fog setting, from selected player(s), that matches the user provided ID (i.e. as provided previously via a "/fog push" command).</br>



=== Remove ===


Removes all matching fog settings, from the selected player(s), that matches the user-provided ID (i.e. as provided previously via one or more "/fog push" commands).</br>





