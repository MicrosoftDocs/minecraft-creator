{{exclusive|bedrock}}
{{TOC|right}}
{{see also|Bedrock Edition beta add-on documentation}}
This is the '''[[add-on]] documentation''' for [[Bedrock Edition 1.17.6]].
=Version: 1.17.40.6=
== Items ==


To define an item, the item definition must be defined in the behavior pack in a JSON file.</br>All attributes, including item names, must be defined using item components.</br>

=== Item Components ===


Below are the various components for item functionality.</br>

: {| class="wikitable"
! Type !! Name !! Default Value !! Description
|-
| JSON Object
| minecraft:armor
| 
| The armor item component determines the amount of protection you have in your armor item.
Experimental toggles required: Holiday Creator Features
 protection 

;

How much protection does the armor item have.</br>Minimum value: 0</br>Type: integer</br>



 texture_type 

;

Texture Type to apply for the armor. Note that Horse armor is restricted to leather, iron, gold, or diamond.</br>Accepted values: "gold", "none", "leather", "chain", "iron", "diamond", "elytra", "turtle", "netherite"</br>



|-
| JSON Object
| minecraft:block_placer
| 
| Planter item component. planter items are items that can be planted.
Experimental toggles required: Holiday Creator Features
 block 

;

block:  Set the placement block name for the planter item.</br>Type: block</br>



 use_on 

;

List of block descriptors that contain blocks that this item can be used on. If left empty, all blocks will be allowed.</br>Type: array of use_on</br>



|-
| JSON Object
| minecraft:cooldown
| 
| Cool down time for a component. After you use an item it becomes unusable for the duration specified by the 'cool down time' setting in this component.
Experimental toggles required: Holiday Creator Features
 category 

;

The type of cool down for this item.</br>Type: category</br>



 duration 

;

The duration of time this item will spend cooling down before becoming usable again.</br>Type: float</br>



|-
| JSON Object
| minecraft:digger
| 
| Digger item. Component put on items that dig.
Experimental toggles required: Holiday Creator Features
 destroy_speeds 

;

Destroy speed per block.</br>Type: array of destroy_speeds</br>



 on_dig 

;

Trigger for when you dig a block that isn't listed in destroy_speeds</br>Type: on_dig</br>



 use_efficiency 

;

Use efficiency? Default is set to false.</br>Type: boolean</br>



|-
| JSON Object
| minecraft:display_name
| 
| Display Name item component. Display Names set the name to display when an item is in use or hovered over.
Experimental toggles required: Holiday Creator Features
 value 

;

The display name for an item.</br>Type: value</br>



|-
| JSON Object
| minecraft:durability
| 
| A property that determines when an item will break from use. The durability of an item is potentially depleted upon use based on the damage chance.
Experimental toggles required: Holiday Creator Features
 damage_chance 

;

Damage chance is the chance of this item losing durability. Could be an int or an int range with min and max value.</br>Type: damage_chance</br>



 max_durability 

;

Max durability is the amount of damage that this item can take before breaking.</br>Type: integer</br>



|-
| JSON Object
| minecraft:dye_powder
| 
| Dye powder, there are 16 kinds of dye.
Experimental toggles required: Holiday Creator Features
 color 

;

Defines what color the dye is.</br>Accepted values: "black", "red", "green", "brown", "blue", "purple", "cyan", "silver", "gray", "pink", "lime", "yellow", "lightblue", "magenta", "orange", "white"</br>



|-
| JSON Object
| minecraft:entity_placer
| 
| Entity placer item component. You can specifiy allowed blocks that the item is restricted to.
Experimental toggles required: Holiday Creator Features
 dispense_on 

;

List of block descriptors that contain blocks that this item can be dispensed on. If left empty, all blocks will be allowed.</br>Type: array of dispense_on</br>



 entity 

;

The entity to be placed in the world.</br>Type: entity</br>



 use_on 

;

List of block descriptors that contain blocks that this item can be used on. If left empty, all blocks will be allowed.</br>Type: array of use_on</br>



|-
| JSON Object
| minecraft:food
| 
| When an item has a food component, it becomes edible to the player.
Experimental toggles required: Holiday Creator Features
 can_always_eat 

;

If true you can always eat this item (even when not hungry), defaults to false.</br>Type: boolean</br>



 nutrition 

;

How much nutrition does this food item give the player when eaten.</br>Type: integer</br>



 on_consume 

;

</br>Type: on_consume</br>



 saturation_modifier 

;

Saturation Modifier is used in this formula: (nutrition * saturation_modifier * 2) when appling the saturation buff. Which happens when you eat the item.</br>Type: saturation_modifier</br>



 using_converts_to 

;

When used, convert the *this* item to the one specified by 'using_converts_to'.</br>Type: using_converts_to</br>



|-
| JSON Object
| minecraft:fuel
| 
| Fuel component. Allows this item to be used as fuel in a furnace to 'cook' other items.
Experimental toggles required: Holiday Creator Features
 duration 

;

How long in seconds will this fuel cook items for.</br>Type: float</br>



|-
| JSON Object
| minecraft:icon
| 
| The icon item component determines the icon to represent the item.
Experimental toggles required: Holiday Creator Features
 frame 

;

An index or MoLang expression for which frame of the icon to display. Default resolves to 0.</br>Type: frame</br>



 legacy_id 

;

Legacy texture string id for older item icons. Legacy ID list can be found here under 'Namespaced ID': https://minecraft.fandom.com/wiki/Bedrock_Edition_data_values</br>Type: string</br>



 texture 

;

The key for the object contain the expected textures, from file 'resource_pack/textures/item_texture.json'.</br>Type: string</br>



|-
| JSON Object
| minecraft:knockback_resistance
| 
| Knockback Resistance Item. Component put on items that provide knockback resistance.
Experimental toggles required: Holiday Creator Features
 protection 

;

Amount of knockback resistance provided with the total maximum protection being 1.0</br>Type: float</br>



|-
| JSON Object
| minecraft:on_use
| 
| The on_use item component allows you to receive an event when the item is used.
Experimental toggles required: Holiday Creator Features
 on_use 

;

Event trigger for when the item is used.</br>Type: on_use</br>



|-
| JSON Object
| minecraft:on_use_on
| 
| The on_use_on item component allows you to receive an event when the item is used on a block in the world.
Experimental toggles required: Holiday Creator Features
 on_use_on 

;

Event trigger for when the item is used.</br>Type: on_use_on</br>



|-
| JSON Object
| minecraft:projectile
| 
| Projectile item component. projectile items shoot out, like an arrow.
Experimental toggles required: Holiday Creator Features
 minimum_critical_power 

;

How long you must charge a projectile for it to critically hit.</br>Type: float</br>



 projectile_entity 

;

The entity to be fired as a projectile.</br>Type: projectile_entity</br>



|-
| JSON Object
| minecraft:render_offsets
| 
| Render offsets component: optional values can be given to offset the way the item is rendered.
Experimental toggles required: Holiday Creator Features
 main_hand 

;

Main hand transform data.</br>Type: main_hand</br>



 off_hand 

;

Offhand hand transform data.</br>Type: off_hand</br>



|-
| JSON Object
| minecraft:repairable
| 
| Repairable item component: how much damage can this item repair, what items can repair it.
Experimental toggles required: Holiday Creator Features
 on_repaired 

;

Event that is called when this item has been repaired.</br>Type: on_repaired</br>



 repair_items 

;

Repair item entries.</br>Type: array of repair_items</br>



|-
| JSON Object
| minecraft:shooter
| 
| Shooter Item Component.
Experimental toggles required: Holiday Creator Features
 ammunition 

;

Ammunition.</br>Type: array of ammunition</br>



 charge_on_draw 

;

Charge on draw? Default is set to false.</br>Type: boolean</br>



 launch_power_scale 

;

Launch power scale. Default is set to 1.0.</br>Type: float</br>



 max_draw_duration 

;

Draw Duration. Default is set to 0.</br>Type: max_draw_duration</br>



 max_launch_power 

;

Launch power. Default is set to 1.0.</br>Type: float</br>



 scale_power_by_draw_duration 

;

Scale power by draw duration? Default is set to false.</br>Type: boolean</br>



|-
| JSON Object
| minecraft:throwable
| 
| Throwable item component. Throwable items, such as a snowball.
Experimental toggles required: Holiday Creator Features
 do_swing_animation 

;

Whether the item should use the swing animation when thrown. Default is set to false.</br>Type: boolean</br>



 launch_power_scale 

;

The scale at which the power of the throw increases. Default is set to 1.0.</br>Type: float</br>



 max_draw_duration 

;

The maximum duration to draw a throwable item. Default is set to 0.0.</br>Type: float</br>



 max_launch_power 

;

The maximum power to launch the throwable item. Default is set to 1.0.</br>Type: float</br>



 min_draw_duration 

;

The minimum duration to draw a throwable item. Default is set to 0.0.</br>Type: float</br>



 scale_power_by_draw_duration 

;

Whether or not the power of the throw increases with duration charged. Default is set to false.</br>Type: boolean</br>



|-
| JSON Object
| minecraft:weapon
| 
| Weapon Item Component. Added to every weapon item such as axe, sword, trident, bow, crossbow.
Experimental toggles required: Holiday Creator Features
 on_hit_block 

;

Trigger for letting you know when this item is used to hit a block</br>Type: on_hit_block</br>



 on_hurt_entity 

;

Trigger for letting you know when this item is used to hurt another mob</br>Type: on_hurt_entity</br>



 on_not_hurt_entity 

;

Trigger for letting you know when this item hit another actor, but didn't do damage</br>Type: on_not_hurt_entity</br>



|-
| JSON Object
| minecraft:wearable
| 
| Wearable item component.
Experimental toggles required: Holiday Creator Features
 slot 

;

equipment_slot: slot.weapon.mainhand, slot.weapon.offhand, slot.armor.head, slot.armor.chest, slot.armor.legs, slot.armor.feet, slot.hotbar, slot.inventory, slot.enderchest, slot.saddle, slot.armor, slot.chest</br>Accepted values: "slot.armor.legs", "none", "slot.weapon.mainhand", "slot.weapon.offhand", "slot.armor.head", "slot.armor.chest", "slot.armor.feet", "slot.hotbar", "slot.inventory", "slot.enderchest", "slot.saddle", "slot.armor", "slot.chest"</br>



|}


=== Item Definition Properties ===


The properties are part of the Item Definition. This helps the system determine how to parse and initialize this item.</br>

==== format_version ====

;

Specifies the version of the game this entity was made in. If the version is lower than the current version, any changes made to the entity in the vanilla version will be applied to it.</br>



;Code Example

: Example

<pre>{
  "format_version": "1.16.1",
  "minecraft:item": {
    "description": {
      "identifier": "minecraft:blaze_rod"
    },
    "components": {
      "minecraft:fuel": {
        "duration": 120.0
      },
      "minecraft:max_stack_size": 64,
      "minecraft:icon": {
        "texture": "blaze_rod"
      },
      "minecraft:hand_equipped": true,
      "minecraft:display_name": {
        "value": "Blaze Rod"
      }
    }
  }
}</pre>



=== Item Description Properties ===

: {| class="wikitable"
! Type !! Name !! Default Value !! Description
|-
| String
| category
| 
| The category for this item. Categories are used to control high level properties of how the item is integrated into the bedrock engine, such as whether it can be used in slash commands.
|-
| String
| identifier
| 
| The identifier for this item. The name must include a namespace and must not use the Minecraft namespace unless overriding a Vanilla item.
|-
| Boolean
| is_experimental
| false
| If this item is experimental, it will only be registered if the world is marked as experimental.
|}




