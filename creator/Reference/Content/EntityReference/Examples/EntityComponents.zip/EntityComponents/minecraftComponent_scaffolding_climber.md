---
author: v-jeffreykim
ms.author: v-jeffreykim
title: minecraft:scaffolding_climber
ms.prod: gaming
---
​
# minecraft:scaffolding_climber
​
`minecraft:scaffolding_climber` allows the player to detect and manuever on the scaffolding block.

## Example
​
```json
"minecraft:scaffolding_climber":{}
```
​
## Vanilla entities examples
​
### player

:::code language="json" source="../../../../Source/VanillaBehaviorPack/entities/player.json" range="138":::
​
## Vanilla entities using `minecraft:scaffolding_climber`
​
- [player](../../../../Source/VanillaBehaviorPack_Snippets/entities/player.md)